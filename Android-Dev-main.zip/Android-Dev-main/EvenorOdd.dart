void main(){
  int num = 11;
  if(num%2==0){
    print("It Is Even");
  }
  else{
    print("It Is Odd");
  }
}