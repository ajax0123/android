void main(){
  Set<int> num = {1, 2, 3, 4};
  num.add(5);
  print(num);
  num.remove(2);
  print(num);
}