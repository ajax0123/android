void  main(){
  Map<String , dynamic> mapData = {
    'Name':'Alice',
    'age':25,
    'city':'New York'
  };
  mapData['Country']='USA';
  mapData['age'] = 26;
  print(mapData);
}