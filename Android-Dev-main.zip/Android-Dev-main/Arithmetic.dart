void main(){
  int a = 10;
  int b = 5;
 
  int sum = a+b;
  print('The Sum Of a + b is: ${sum}');

  int diff = a-b;
  print('The Difference of a and b is: ${diff}');
  
  int product = a*b;
  print('The product of a and b is: ${product} ');

  double Quotient = a/b;
  print('The Quotient Of a and b is: ${Quotient}');
  
}