void main(){
  List<int> num = [5, 3, 8, 1, 2];
  num.add(7);
  print(num);
  num.sort();
  print(num);
}