void main(){
  List<int> Num = [1 , 2 , 3 , 4 , 5];

  Num.forEach((Num){
    print(Num*Num);
  });
}